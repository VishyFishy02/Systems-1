/*
  BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO THE
  TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY WITH RESPECT TO
  THIS ASSIGNMENT.
*/


unsigned char rotate_right(int shift);
unsigned char rotate_left(int shift);
unsigned int create_key();
